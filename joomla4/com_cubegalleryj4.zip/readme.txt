CubeGallery version 1.0.0  is a free software which is developed by
Kian William Nowrouzian. It is a package including both component and module.
Module is using the site part component's model, so without it, it will not work.
The license is GNU/GPLv3
It is written for joomla 3.x,
in comment part for special characters add backslash(\) before them.
you may download the component at:http://www.myextenstions.lord121.ir/2015-12-17-11-58-05/picard.html
In case of any problem contact me at:
mezmer121@gmail.com
long live science.
